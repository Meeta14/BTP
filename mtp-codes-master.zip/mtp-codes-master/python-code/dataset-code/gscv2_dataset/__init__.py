"""gscv2_dataset dataset."""

from .gscv2_dataset import Gscv2Dataset
