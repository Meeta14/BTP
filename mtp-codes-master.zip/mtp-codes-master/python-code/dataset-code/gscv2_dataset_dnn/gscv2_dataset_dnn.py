"""gscv2_dataset_dnn dataset."""
import librosa                                                                                                  
import numpy as np
import os
import random
import tensorflow as tf
import tensorflow_datasets as tfds
from tensorflow_datasets.core import lazy_imports_lib

# TODO(gscv2_dataset_dnn): Markdown description  that will appear on the catalog page.
_DESCRIPTION = """
"""

# TODO(gscv2_dataset_dnn): BibTeX citation
_CITATION = """
"""

_DOWNLOAD_PATH = 'https://www.ee.iitb.ac.in/~shyamap/dataset_v2_mod.zip'

SPLITS = ['train', 'valid', 'test']

# Valid keywords
WORDS = ['down', 'go', 'left', 'no', 'off', 'on', 'right', 'stop', 'up', 'yes'] # 'silence', 'unknown'
SILENCE = '_silence_'
UNKNOWN = '_unknown_'
BACKGROUND_NOISE = '_background_noise_'

# Probability that sample has noise
NOISE_P = 0.8
# Probability that silence is background noise
BG_NOISE_P = 0.8
# Scale of noise amplitude while adding to audio samples (max value)
NOISE_LOUDNESS = 0.1
# Time shift range is -TIME_SHIFT to TIME_SHIFT
TIME_SHIFT = 100
# Array to store all noise files temporarily
noise_data = []

# MFCC parameters
N_FFT = 1024
# Audio samples' sampling rate
SAMPLE_RATE = 16000
# In terms of no. of samples
HOP_LENGTH = int(40 * SAMPLE_RATE /1000)
WINDOW_LENGTH = int(40 * SAMPLE_RATE /1000)

# No. of time slices
N_FEATURES = int((SAMPLE_RATE - WINDOW_LENGTH)//HOP_LENGTH + 1)

N_DCT_FILTERS = 10
N_MELS = 10
F_MIN = 20
F_MAX = 4000

DCT_FILTERS = librosa.filters.dct(N_DCT_FILTERS, N_MELS)
MEL_BASIS = librosa.filters.mel(SAMPLE_RATE, N_FFT, n_mels=N_MELS, fmin=F_MIN, fmax=F_MAX, htk=True)

Z = lambda t: np.pad(t,pad_width=(N_FFT-WINDOW_LENGTH)//2,mode='constant')

class Gscv2DatasetDnn(tfds.core.GeneratorBasedBuilder):
  """DatasetBuilder for gscv2_dataset_dnn dataset."""

  VERSION = tfds.core.Version('2.0.0')
  RELEASE_NOTES = {
      '2.0.0': 'Initial release.',
  }

  def _info(self) -> tfds.core.DatasetInfo:
    """Returns the dataset metadata."""
    return tfds.core.DatasetInfo(
        builder=self,
        description=_DESCRIPTION,
        features=tfds.features.FeaturesDict({
            'audio':tfds.features.Tensor(dtype=tf.float32, shape=(250,1)),
            'label': tfds.features.ClassLabel(names=WORDS + [SILENCE, UNKNOWN]),
        }),
        supervised_keys=('audio', 'label'),  # Set to `None` to disable
        homepage='https://dataset-homepage/',
        citation=_CITATION,
    )

  def _split_generators(self, dl_manager: tfds.download.DownloadManager):
    """Returns SplitGenerators."""
    dl_path = dl_manager.download(_DOWNLOAD_PATH)

    train_paths, validation_paths, test_paths = self._split_archive(dl_manager.iter_archive(dl_path))

    return [
        tfds.core.SplitGenerator(
            name=tfds.Split.TRAIN,
            gen_kwargs={'archive': dl_manager.iter_archive(dl_path),
                        'file_list': train_paths,
                        'is_train': True}, 
        ),
        tfds.core.SplitGenerator(
            name=tfds.Split.VALIDATION,
            gen_kwargs={'archive': dl_manager.iter_archive(dl_path),
                        'file_list': validation_paths,
                        'is_train': False}, 
        ),
        tfds.core.SplitGenerator(
            name=tfds.Split.TEST,
            gen_kwargs={'archive': dl_manager.iter_archive(dl_path),
                        'file_list': test_paths,
                        'is_train': False}, 
        ),
    ]

  def _split_archive(self, train_archive):
    for path, file_obj in train_archive:
      relpath, wavname = os.path.split(path)
      _, word = os.path.split(relpath)

      if word == SILENCE or word == BACKGROUND_NOISE:
        noise_data.append(file_obj)
      if 'testing_list.txt' in path:
        test_paths = file_obj.read().strip().splitlines()
        test_paths = [f"dataset_v2/{p.decode('ascii')}" for p in test_paths]
      elif 'validation_list.txt' in path:
        validation_paths = file_obj.read().strip().splitlines()
        validation_paths = [f"dataset_v2/{p.decode('ascii')}" for p in validation_paths]
      elif 'train_list.txt' in path:
        train_paths = file_obj.read().strip().splitlines()
        train_paths = [f"dataset_v2/{p.decode('ascii')}" for p in train_paths]
    
    return train_paths, validation_paths, test_paths

  def _generate_examples(self, archive, file_list, is_train=False):
    """Yields examples."""
    i = 0
    length = int(0.1 * len(file_list))

    for path, file_obj in archive:
      if path not in file_list:
        continue
      relpath, wavname = os.path.split(path)
      _, word = os.path.split(relpath)
      example_id = '{}_{}'.format(word, wavname)
      if word in WORDS:
        label = word
      elif word == SILENCE or word == BACKGROUND_NOISE:
        label = SILENCE
      else:
        label = UNKNOWN
      p = random.random()
      if p < NOISE_P and is_train:
        noise = random.choice(noise_data)
        noise_volume = random.uniform(0,NOISE_LOUDNESS)
        noise = np.array(lazy_imports_lib.lazy_imports.pydub.AudioSegment.from_file(noise, format='wav').get_array_of_samples())/2**15                                                                                                              
        start = random.randint(0,len(noise)-16000-1)
        noise = np.array(noise[start:start+16000])
        noise = noise_volume * noise
      else:
        noise = np.zeros(16000, dtype=np.float32)

      if word == BACKGROUND_NOISE:
        if i < length:
          audio_samples = np.array(lazy_imports_lib.lazy_imports.pydub.AudioSegment.from_file(file_obj, format='wav').get_array_of_samples())/2**15
          for start in range(0,len(audio_samples) - SAMPLE_RATE, SAMPLE_RATE):
            if random.random() < BG_NOISE_P:
              audio_segment = audio_samples[start:start + SAMPLE_RATE]
            else:
              audio_segment = np.zeros(16000, dtype=np.float32)
            
            cur_id = '{}_{}'.format(example_id, start)
            example = {'audio': self.mfcc(audio_segment), 'label': label}
            i += 1
            yield cur_id, example
      else:
        try:
          audio_input = np.array(lazy_imports_lib.lazy_imports.pydub.AudioSegment.from_file(file_obj,
                              format='wav').get_array_of_samples())/2**15                                                                                                             
          audio_input = np.concatenate((audio_input,np.zeros(16000-audio_input.shape[0])))
          ts = random.randint(-TIME_SHIFT, TIME_SHIFT)
          
          if ts < 0:
            audio_input = np.concatenate((audio_input[-ts:],np.zeros(-ts)))
          elif ts > 0:
            audio_input = np.concatenate((np.zeros(ts), audio_input[:-ts]))

          audio_input = np.clip(audio_input + noise, -1.0, 1.0)
          example = {
                    'audio': self.mfcc(audio_input),
                    'label': label,
          }
          yield example_id, example
        except lazy_imports_lib.lazy_imports.pydub.exceptions.CouldntDecodeError:
          pass

  def mfcc(self, audio_input):
    # Pad the input
    y_padded = np.zeros((N_FEATURES,N_FFT))
    for i in range(N_FEATURES):
      y_padded[i,:] = Z(audio_input[i * HOP_LENGTH : i * HOP_LENGTH + WINDOW_LENGTH])
    y_padded = y_padded.reshape(-1)
    # Compute spectrogram
    spectrogram = np.abs(librosa.stft(
                            y_padded,
                            n_fft=N_FFT,
                            hop_length=N_FFT,
                            win_length=N_FFT,
                            center=False,
                            window='hann',
                            pad_mode='constant'))**2
    # Compute mel spectrogram
    mel_spec = np.dot(MEL_BASIS,spectrogram)
    # Take log
    mel_spec[mel_spec > 0] = np.log(mel_spec[mel_spec > 0])
    mfcc = [np.matmul(DCT_FILTERS, x) for x in np.split(mel_spec,mel_spec.shape[1], axis=1)]
    mfcc = np.array(mfcc, order="F",dtype=np.float32).reshape((N_FEATURES*N_MELS,1))
    return mfcc
