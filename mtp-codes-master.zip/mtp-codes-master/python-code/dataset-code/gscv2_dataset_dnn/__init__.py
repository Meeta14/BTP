"""gscv2_dataset_dnn dataset."""

from .gscv2_dataset_dnn import Gscv2DatasetDnn
