"""gscv2_dataset_mfcc10 dataset."""

from .gscv2_dataset_mfcc10 import Gscv2DatasetMfcc10
